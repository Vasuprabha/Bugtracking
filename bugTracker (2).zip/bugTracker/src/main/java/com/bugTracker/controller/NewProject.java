package com.bugTracker.controller;

import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugTracker.dao.NewProjectDao;
import com.bugTracker.model.Project;
import com.bugTracker.model.Response;

@RestController
@RequestMapping("/newUser")
public class NewProject {

	@Autowired
	NewProjectDao newProject;
	Logger log = LogManager.getLogger(NewProject.class);

	@PostMapping(value = "/addUser", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Response addProject(@RequestBody Project project) {
		try {
			PreparedStatement userDetails = newProject.addProject(project);
			if (userDetails != null) {
				log.info("Project details inserted successfully");
				return new Response(HttpStatus.OK.value(), "Project details inserted", "Success",
						project.getProjectName());
			} else {
				log.info("Project details insertion failed");
				return new Response(HttpStatus.NOT_FOUND.value(), "Project details not inserted", "Failure", null);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.NOT_ACCEPTABLE.value(), "Exception : ", "Failure", null);
	}
}

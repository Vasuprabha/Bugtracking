package com.bugTracker.dao;

public class ExistIssue {

}

package com.bugTracker.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bugTracker.controller.ExistProject;
import com.bugTracker.model.Project;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class ExistProjectDao {

	@Autowired
	ConnectionPooling connectionPooling;
	Logger log = LogManager.getLogger(ExistProjectDao.class);

	public ArrayList<Project> viewProjectDetails(int projectId) {
		try {
			String query = "sp_viewProjectDetails @projectId= '" + projectId + "'";
			PreparedStatement preparedStatement = connectionPooling.source().prepareStatement(query);
			ResultSet data = preparedStatement.executeQuery();
			ArrayList<Project> userDetails = new ArrayList<Project>();
			Project project = null;
			while (data.next()) {
				 project = new Project();
//				userDetails.add(new Project(data.getInt("projectId"), data.getString("projectName"),
//						data.getDate("startDate"), data.getDate("expectedEndDate"), data.getDate("actualEndDate"),
//						data.getString("status"),data.getInt("createdBy"), data.getDate("createdOn"), data.getInt("updatedBy"),
//						data.getDate("updatedOn"));
				
				 project.setProjectId(data.getInt("projectId"));
				 project.setProjectName(data.getString("projectName"));
				 project.setStartDate(data.getDate("startDate"));
				 project.setExpectedEndDate(data.getDate("expectedEndDate"));
				 project.setActualEndDate(data.getDate("actualEndDate"));
				 project.setStatus(data.getString("status"));
				 project.setCreatedOn(data.getDate("createdOn"));
				 project.setCreatedBy(data.getInt("createdBy"));
				 project.setUpdatedOn(data.getDate("updatedOn"));
				 project.setUpdatedBy(data.getInt("updatedBy"));
				userDetails.add(project);
				log.info("Data retrived");				
			}
			return userDetails;
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;

	}
}

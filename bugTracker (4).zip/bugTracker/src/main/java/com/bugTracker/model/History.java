package com.bugTracker.model;

import java.sql.Date;

public class History {

	private int historyId;
	private Issue issueId;
	private Project projectId;
	private String description;
	private User assignedBy;
	private User assignedTo;
	private User updatedBy;
	private Date updatedOn;

	public History(int historyId, Issue issueId, Project projectId, String description, User assignedBy,
			User assignedTo, User updatedBy, Date updatedOn) {

		this.historyId = historyId;
		this.issueId = issueId;
		this.projectId = projectId;
		this.description = description;
		this.assignedBy = assignedBy;
		this.assignedTo = assignedTo;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
	}

	public History() {
	}

	public int getHistoryId() {
		return historyId;
	}

	public void setHistoryId(int historyId) {
		this.historyId = historyId;
	}

	public Issue getIssueId() {
		return issueId;
	}

	public void setIssueId(Issue issueId) {
		this.issueId = issueId;
	}

	public Project getProjectId() {
		return projectId;
	}

	public void setProjectId(Project projectId) {
		this.projectId = projectId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public User getAssignedBy() {
		return assignedBy;
	}

	public void setAssignedBy(User assignedBy) {
		this.assignedBy = assignedBy;
	}

	public User getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}

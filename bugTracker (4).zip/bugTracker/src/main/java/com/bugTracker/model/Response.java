package com.bugTracker.model;

public class Response {

	private int responseCode;
	private String message;
	private String status;
	private Object responseBody;

	public Response(int responseCode, String message, String status, Object responseBody) {
		super();
		this.responseCode = responseCode;
		this.message = message;
		this.status = status;
		this.responseBody = responseBody;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Object responseBody) {
		this.responseBody = responseBody;
	}

}
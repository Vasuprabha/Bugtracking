package com.bugTracker.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bugTracker.dao.ExistUserDao;
import com.bugTracker.model.Response;
import com.bugTracker.model.User;

@RestController
@RequestMapping("/existUser")
public class ExistUser {

	@Autowired
	ExistUserDao user;
	Logger log = LogManager.getLogger(ExistUser.class);

	@GetMapping(value = "/login")
	public Response login(@RequestParam(value = "userId") int userId,
			@RequestParam(value = "password") String password) {
		try {
			int loginId = user.login(userId, password);
			if (loginId != 0) {
				log.info("User id and Password matched");
				return new Response(HttpStatus.OK.value(), "User id and Password matched", "Success", loginId);
			} else {
				log.info("Invalid credentials");
				return new Response(HttpStatus.NOT_FOUND.value(), "User id and Password not matched", "Failure", loginId);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.BAD_REQUEST.value(), "Exception occured", "Failure", 0);
	}

	@GetMapping(value = "/viewUserDetails")
	public Response viewUserDetails(@RequestParam(value = "userId") int userId) {
		try {
			User userDetails = new User();
			userDetails = user.viewUserDetails(userId);
			if (userDetails != null) {
				log.info("User id matched");
				return new Response(HttpStatus.OK.value(), "User id matched", "Success", userDetails);
			} else {
				log.info("User id not matched");
				return new Response(HttpStatus.NOT_FOUND.value(), "User id not matched", "Failure", userDetails);
			}
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.BAD_REQUEST.value(), "Exception occured", "Failure", null);
	}

	@PostMapping(value = "/updateStatus")
	public Response updateUserStatus(@RequestBody User users) {
		try {
			String updatedStatus = user.updateUserStatus(users);
			if (updatedStatus != null) {
				log.info("User status updated");
				return new Response(HttpStatus.OK.value(), "User status updated ", "Success",
						"Status : " + updatedStatus);
			} else {
				log.info("User status not updated");
				return new Response(HttpStatus.NOT_FOUND.value(), "User status not updated ", "Failure", updatedStatus);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.BAD_REQUEST.value(), "Exception occured", "Failure", null);
	}
}

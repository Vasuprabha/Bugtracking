package com.bugTracker.controller;

import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugTracker.dao.NewIssueDao;
import com.bugTracker.model.Issue;
import com.bugTracker.model.Response;

@RestController
@RequestMapping("/newIssue")
public class NewIssue {
	@Autowired
	NewIssueDao newIssue;
	Logger log = LogManager.getLogger(NewIssue.class);

	@PostMapping(value = "/addIssue")
	public Response addUser(@RequestBody Issue issue) {
		try {
			PreparedStatement issueDetails = newIssue.addIssue(issue);
			if (issueDetails != null) {
				log.info("Issue details inserted successfully");
				return new Response(HttpStatus.OK.value(), "Issue details inserted", "Success", issue.getIssueId());
			} else {
				log.info("User details insertion failed");
				return new Response(HttpStatus.NOT_FOUND.value(), "Issue details not inserted", "Failure", null);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.NOT_ACCEPTABLE.value(), "Exception : ", "Failure", null);
	}
}
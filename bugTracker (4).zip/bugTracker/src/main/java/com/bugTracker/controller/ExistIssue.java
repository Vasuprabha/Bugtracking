package com.bugTracker.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bugTracker.dao.ExistIssueDao;
import com.bugTracker.model.Issue;
import com.bugTracker.model.Response;

@RestController
@RequestMapping("/existIssue")
public class ExistIssue {
	@Autowired
	ExistIssueDao issue;
	Logger log = LogManager.getLogger(ExistIssue.class);

	@GetMapping(value = "/viewIssueDetails")
	public Response viewIssueDetails(@RequestParam(value = "issueId") int issueId) {
		try {
			Issue issueDetails = new Issue();
			issueDetails = issue.viewIssueDetails(issueId);
			if (issueDetails != null) {
				log.info("Issue id matched");
				return new Response(HttpStatus.OK.value(), "Issue id matched", "Success", issueDetails);
			} else {
				log.info("Issue id not matched");
				return new Response(HttpStatus.OK.value(), "Issue id not matched", "Failure", issueDetails);
			}
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.OK.value(), "Exception occured", "Failure", null);
	}

	@PostMapping(value = "/updateStatus")
	public Response updateIssueStatus(@RequestBody Issue issueStatus) {
		try {
			String updatedStatus = issue.updateIssueStatus(issueStatus);
			if (updatedStatus != null) {
				return new Response(HttpStatus.OK.value(), "Issue status updated ", "Success",
						"Status : " + updatedStatus);
			} else {
				return new Response(HttpStatus.NOT_FOUND.value(), "Issue status not updated ", "Failure",
						updatedStatus);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.OK.value(), "Exception occured", "Failure", null);
	}

	@PostMapping(value = "/updateAssignee")
	public Response updateAssignee(@RequestBody Issue updateAssignee) {
		try {
			Issue updateAssigneeDetails = issue.updateAssignee(updateAssignee);
			if (updateAssigneeDetails != null) {
				return new Response(HttpStatus.OK.value(), "Issue status updated ", "Success", updateAssigneeDetails);
			} else {
				return new Response(HttpStatus.NOT_FOUND.value(), "Issue status not updated ", "Failure",
						updateAssigneeDetails);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.OK.value(), "Exception occured", "Failure", null);
	}
}

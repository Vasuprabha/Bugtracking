package com.bugTracker.controller;

import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugTracker.dao.NewUserDao;
import com.bugTracker.model.Response;
import com.bugTracker.model.User;

@RestController
@RequestMapping("/newUser")
public class NewUser {
	@Autowired
	NewUserDao newUser;
	Logger log = LogManager.getLogger(NewUser.class);

	@PostMapping(value = "/addUser")
	public Response addUser(@RequestBody User user) {
		try {
			PreparedStatement userDetails = newUser.addUsers(user);
			if (userDetails != null) {
				log.info("User details inserted successfully");
				return new Response(HttpStatus.OK.value(), "User details inserted", "Success", user.getUserName());
			} else {
				log.info("User details insertion failed");
				return new Response(HttpStatus.NOT_FOUND.value(), "User details not inserted", "Failure", null);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.BAD_REQUEST.value(), "Exception : ", "Failure", null);
	}
}

package com.bugTracker.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bugTracker.dao.ExistProjectDao;
import com.bugTracker.model.Project;
import com.bugTracker.model.Response;

@RestController
@RequestMapping("/existProject")
public class ExistProject {
	@Autowired
	ExistProjectDao projects;
	Logger log = LogManager.getLogger(ExistProject.class);

	@GetMapping(value = "/viewProjectDetails")
	public Response viewProjectDetails(@RequestParam(value = "projectId") int projectId) {
		try {
			Project projectDetails = new Project();
			projectDetails = projects.viewProjectDetails(projectId);
			if (projectDetails != null) {
				log.info("Project id matched");
				return new Response(HttpStatus.OK.value(), "Project id matched", "Success", projectDetails);
			} else {
				log.info("Project id not matched");
				return new Response(HttpStatus.NOT_FOUND.value(), "Project id not matched", "Failure", projectDetails);
			}
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.BAD_REQUEST.value(), "Exception occured", "Failure", null);
	}

	@PostMapping(value = "/updateStatus")
	public Response updateUserStatus(@RequestBody Project project) {
		try {
			String updatedStatus = projects.updateProjectStatus(project);
			if (updatedStatus != null) {
				log.info("Project status updated");
				return new Response(HttpStatus.OK.value(), "Project status updated ", "Success",
						"Status : " + updatedStatus);
			} else {
				log.info("User status not updated");
				return new Response(HttpStatus.NOT_FOUND.value(), "Project status not updated ", "Failure",
						updatedStatus);
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return new Response(HttpStatus.OK.value(), "Exception occured", "Failure", null);
	}
}

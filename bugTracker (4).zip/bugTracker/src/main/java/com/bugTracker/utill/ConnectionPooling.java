package com.bugTracker.utill;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class ConnectionPooling {

	String driver = null;
	String dbUrl = null;
	String userName = null;
	String password = null;

	private static BasicDataSource dataSource = new BasicDataSource();
	Logger log = LogManager.getLogger(ConnectionPooling.class);

	public BasicDataSource dbConnection() throws IOException {

		try {
			FileInputStream file = null;
			file = new FileInputStream("D:\\My Task\\BankingServices\\src\\main\\resources\\application.properties");
			Properties property = new Properties();
			property.load(file);

			driver = property.getProperty("spring.datasource.driverClassName");
			dbUrl = property.getProperty("spring.datasource.url");
			userName = property.getProperty("spring.datasource.username");
			password = property.getProperty("spring.datasource.password");
			log.info("Property file worked");
			dataSource = new BasicDataSource();
			dataSource.setDriverClassName(driver);
			dataSource.setUrl(dbUrl);
			dataSource.setUsername(userName);
			dataSource.setPassword(password);

			dataSource.setMinIdle(5);
			dataSource.setMaxIdle(10);
			dataSource.setMaxTotal(25);
		} catch (Exception e) {
			log.error(e);

		}
		return dataSource;
	}

	public Connection source() throws SQLException {
		Connection connection = null;
		try {
			dataSource = new ConnectionPooling().dbConnection();
			connection = dataSource.getConnection();
			log.info("Connection Created");
			return connection;

		} catch (Exception e) {
			log.error("Exception in Connection Operation" + e);
			return connection;

		}
	}
}
package com.bugTracker.dao;

import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bugTracker.model.Project;
import com.bugTracker.model.User;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class NewProjectDao {

	@Autowired
	ConnectionPooling connectionPooling;

	Logger log = LogManager.getLogger(NewProjectDao.class);

	public PreparedStatement addProject(Project project) {
		try {
			String insertProjectDetails = "exec sp_projectDetails @projectName=?,@startDate=?,@expectedEndDate=?,@actualEndDate=?,@status=?,@createdBy=?,@updatedBy=?";
			PreparedStatement data = null;
			data = connectionPooling.source().prepareStatement(insertProjectDetails);
			data.setString(1, project.getProjectName());
			data.setDate(2, project.getStartDate());
			data.setDate(3, project.getExpectedEndDate());
			data.setDate(4, project.getActualEndDate());
			data.setString(5, project.getStatus());
//			data.setInt(6, project.getCreatedBy().getUserId());
//			data.setInt(6, project.setCreatedBy((User).getUserId));
			data.setInt(6, project.getCreatedBy());
			project.setCreatedby(User.getUserId());
			data.setInt(7, project.getUpdatedBy().getUserId());
			data.execute();
			log.info("Data inserted sucessfully!!");
			return data;

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}
}

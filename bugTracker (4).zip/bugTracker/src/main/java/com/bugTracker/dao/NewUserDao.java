package com.bugTracker.dao;

import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bugTracker.model.User;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class NewUserDao {
	@Autowired
	ConnectionPooling connectionPooling;

	Logger log = LogManager.getLogger(NewUserDao.class);

	public PreparedStatement addUsers(User user) {
		try {
			String insertUserDetails = "exec spUserDetails @userName=?@,eMail=?,@password=?,@userRole=?,@status=?,@createdBy=?,@updatedBy=?";
			PreparedStatement data = null;
			data = connectionPooling.source().prepareStatement(insertUserDetails);
			data.setString(1, user.getUserName());
			data.setString(2, user.geteMail());
			data.setString(3, user.getPassword());
			data.setString(4, user.getUserRole());
			data.setString(5, user.getStatus());
			data.setString(6, user.getCreatedBy());
			data.setString(7, user.getUpdatedBy());
			data.execute();
			log.info("Data inserted sucessfully!!");
			return data;

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}
}

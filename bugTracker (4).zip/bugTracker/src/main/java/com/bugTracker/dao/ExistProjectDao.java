package com.bugTracker.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import com.bugTracker.model.User;

import com.bugTracker.model.Project;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class ExistProjectDao {

	@Autowired
	ConnectionPooling connectionPooling;
	Logger log = LogManager.getLogger(ExistProjectDao.class);

	public Project viewProjectDetails(int projectId) {
		try {
			String query = "sp_viewProjectDetails @projectId= '" + projectId + "'";
			PreparedStatement preparedStatement = connectionPooling.source().prepareStatement(query);
			ResultSet data = preparedStatement.executeQuery();
			Project project = null;
			while (data.next()) {
				project = new Project();
				project.setProjectId(data.getInt("projectId"));
				project.setProjectName(data.getString("projectName"));
				project.setStartDate(data.getDate("startDate"));
				project.setExpectedEndDate(data.getDate("expectedEndDate"));
				project.setActualEndDate(data.getDate("actualEndDate"));
				project.setStatus(data.getString("status"));
				project.setCreatedOn(data.getDate("createdOn"));
				project.setCreatedBy((User) (data.getObject("createdBy")));
				project.setUpdatedOn(data.getDate("updatedOn"));
				project.setUpdatedBy((User) (data.getObject("updatedBy")));
				log.info("Data retrived");
			}
			return project;
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;

	}

	public String updateProjectStatus(Project project) {
		try {
			String query = "exec sp_updateProjectStatus @projectId=?,@status=?,@updatedBy=?";
			PreparedStatement data = connectionPooling.source().prepareStatement(query);
			data.setInt(1, project.getProjectId());
			data.setString(2, project.getStatus());
			data.setObject(3, project.getUpdatedBy().getUserId());
			data.executeUpdate();
			log.info("Status updated");
			log.info(project.getStatus());

			return project.getStatus();
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}
}

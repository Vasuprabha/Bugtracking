package com.bugTracker.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bugTracker.model.History;
import com.bugTracker.model.Issue;
import com.bugTracker.model.Project;
import com.bugTracker.model.User;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class ExistIssueDao {

	@Autowired
	ConnectionPooling connectionPooling;
	Logger log = LogManager.getLogger(ExistIssueDao.class);

	public Issue viewIssueDetails(int issueId) {
		try {
			String query = "sp_viewIssueDetails @issueId= '" + issueId + "'";
			PreparedStatement preparedStatement = connectionPooling.source().prepareStatement(query);
			ResultSet data = preparedStatement.executeQuery();
			Issue issue = null;
			while (data.next()) {
				issue = new Issue();
				issue.setIssueId(data.getInt("issueId"));
				issue.setSummery(data.getString("summery"));
				issue.setDescription(data.getString("description"));
				issue.setRaisedBy((User) (data.getObject("raisedBy")));
				issue.setCreatedOn(data.getDate("createdOn"));
				issue.setAssignedBy((User) (data.getObject("assignedBy")));
				issue.setAssignedTo((User) (data.getObject("assignedTo")));
				issue.setProjectId((Project) (data.getObject("projectId")));
				issue.setStatus(data.getString("status"));
				issue.setPriority(data.getString("priority"));
				issue.setResolution(data.getString("resolution"));
				issue.setExpectedResolutionDate(data.getDate("expectedResolutionDate"));
				issue.setActualResolutionDate(data.getDate("actualResolutionDate"));
				issue.setIssueVersion(data.getFloat("issueVersion"));
				issue.setFixVersion(data.getFloat("fixVersion"));
				issue.setFileAttachmentPath(data.getString("fileAttachmentPath"));
				issue.setUpdatedBy((User) (data.getObject("updatedBy")));
				issue.setUpdatedOn(data.getDate("updatedOn"));
				log.info("Data retrived");
			}
			return issue;
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;

	}

	public String updateIssueStatus(Issue issue) {
		try {
			String query = "exec sp_updateIssueStatus @issueId=?,@status=?,@updatedBy=?";
			PreparedStatement data = connectionPooling.source().prepareStatement(query);
			data.setInt(1, issue.getIssueId());
			data.setString(2, issue.getStatus());
			data.setObject(3, issue.getUpdatedBy().getUserId());
			data.executeUpdate();
			log.info("Status updated");
			log.info(issue.getStatus());
//			String query ="exec sp_updateHistory @issueId=?,projectId=?,";

			return issue.getStatus();
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}

	public Issue updateAssignee(Issue issue) {
		try {
			
			String query = "exec sp_updateAssignee @issueId=?,@projectId=?,@description=?,@assignedBy=?,@assignedTo=?,@updatedBy=?,@updatedOn=?";
			PreparedStatement data = connectionPooling.source().prepareStatement(query);
			data.setInt(1, issue.getIssueId());
			data.setObject(2, issue.getProjectId().getProjectId());
			data.setString(3, issue.getDescription());
			data.setObject(4, issue.getAssignedBy().getUserId());
			data.setObject(5, issue.getAssignedTo().getUserId());
			data.setObject(6, issue.getUpdatedBy().getUserId());
			data.setDate(7, issue.getUpdatedOn());
			data.executeUpdate();
			log.info("Status updated");
			log.info(issue.getStatus());
			
			History history=null;
			history =new History();
			String updateHistory = "exec sp_updateHistory @issueId=?,@projectId=?,@description=?,@assignedBy=?,@assignedTo=?,@updatedBy=?,@updatedOn=?";
			PreparedStatement historyData = connectionPooling.source().prepareStatement(updateHistory);
			historyData.setObject(1, history.getIssueId().getIssueId());
			historyData.setObject(2, history.getProjectId().getProjectId());
			historyData.setString(3, history.getDescription());
			historyData.setObject(4, history.getAssignedBy().getUserId());
			historyData.setObject(5, history.getAssignedTo().getUserId());
			historyData.setObject(6, history.getUpdatedBy().getUserId());
			historyData.setDate(7, history.getUpdatedOn());

			historyData.executeUpdate();
			log.info("History updated");
			return issue;
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}
}

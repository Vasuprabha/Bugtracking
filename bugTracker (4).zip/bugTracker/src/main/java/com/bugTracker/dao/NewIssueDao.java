package com.bugTracker.dao;

import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bugTracker.model.Issue;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class NewIssueDao {

	@Autowired
	ConnectionPooling connectionPooling;

	Logger log = LogManager.getLogger(NewIssueDao.class);

	public PreparedStatement addIssue(Issue issue) {
		try {
			String insertProjectDetails = "exec sp_projectDetails @summery=?,@description=?,@raisedBy=?,@createdOn=?,@assignedBy=?,@assignedTo=?,@projectId=?,@status=?,@priority=?,@resolution=?,@expectedResolutionDate=?,@actualResolutionDate=?,@issueVersion=?,@fixVersion=?,@attachmentFilePath=?,@updatedBy=?";
			PreparedStatement data = null;
			data = connectionPooling.source().prepareStatement(insertProjectDetails);
			data.setString(1, issue.getSummery());
			data.setString(2, issue.getDescription());
			data.setInt(3, issue.getRaisedBy().getUserId());
			data.setInt(4, issue.getAssignedBy().getUserId());
			data.setInt(5, issue.getAssignedTo().getUserId());
			data.setInt(6, issue.getProjectId().getProjectId());
			data.setString(7, issue.getStatus());
			data.setString(8, issue.getPriority());
			data.setString(9, issue.getResolution());
			data.setDate(10, issue.getExpectedResolutionDate());
			data.setDate(11, issue.getActualResolutionDate());
			data.setFloat(12, issue.getIssueVersion());
			data.setFloat(13, issue.getFixVersion());
			data.setString(14, issue.getFileAttachmentPath());
			data.setInt(15, issue.getUpdatedBy().getUserId());
			data.execute();
			log.info("Data inserted sucessfully!!");
			return data;

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}
}

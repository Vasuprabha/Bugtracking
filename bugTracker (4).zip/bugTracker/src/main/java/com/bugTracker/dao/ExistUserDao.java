package com.bugTracker.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bugTracker.model.User;
import com.bugTracker.utill.ConnectionPooling;

@Configuration
public class ExistUserDao {

	@Autowired
	ConnectionPooling connectionPooling;
	Logger log = LogManager.getLogger(ExistUserDao.class);

	public int login(int userId, String password) {

		try {
			String query = "exec sp_verifyUser @userId ='" + userId + "',@password='" + password + "'";
			PreparedStatement preparedStatement = connectionPooling.source().prepareStatement(query);
			ResultSet data = preparedStatement.executeQuery();
			int id = 0;
			while (data.next()) {
				id = data.getInt("userId");
				log.info("Data retrived");
				log.info(id);
				return id;
			}
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return 0;
	}

	public User viewUserDetails(int userId) {
		try {
			String query = "sp_viewUserDetails @userId= '" + userId + "'";
			PreparedStatement preparedStatement = connectionPooling.source().prepareStatement(query);
			ResultSet data = preparedStatement.executeQuery();
			ArrayList<User> userDetails = new ArrayList<User>();
			User users = null;
			while (data.next()) {
				users = new User();
				users.setUserId(data.getInt("userId"));
				users.setUserName(data.getString("userName"));
				users.seteMail(data.getString("eMail"));
				users.setPassword(data.getString("password"));
				users.setUserRole(data.getString("userRole"));
				users.setStatus(data.getString("status"));
				users.setCreatedOn(data.getDate("createdOn"));
				users.setCreatedBy(data.getString("createdBy"));
				users.setUpdatedOn(data.getDate("updatedOn"));
				users.setUpdatedBy(data.getString("updatedBy"));
				userDetails.add(users);
				log.info(userDetails);
				log.info("Data retrived");
				return users;
			}

		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;

	}

	public String updateUserStatus(User user) {
		try {
			String query = "exec sp_updateUserStatus @userId=?,@status=?,@updatedBy=?";
			PreparedStatement data = connectionPooling.source().prepareStatement(query);
			data.setInt(1, user.getUserId());
			data.setString(2, user.getStatus());
			data.setString(3, user.getUpdatedBy());
			data.executeUpdate();
			log.info("Status updated");
			log.info(user.getStatus());

			return user.getStatus();
		} catch (Exception e) {
			log.error("Exception : " + e);
		}
		return null;
	}

}

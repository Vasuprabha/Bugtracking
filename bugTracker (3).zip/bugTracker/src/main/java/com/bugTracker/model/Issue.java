package com.bugTracker.model;

import java.sql.Date;

public class Issue {

	private int issueId;
	private String summery;
	private String description;
	private User raisedBy;
	private Date createdOn;
	private User assignedBy;
	private User assignedTo;
	private Project projectId;
	private String status;
	private String priority;
	private String resolution;
	private Date expectedResolutionDate;
	private Date actualResolutionDate;
	private float issueVersion;
	private float fixVersion;
	private String fileAttachmentPath;
	private User updatedBy;
	private Date updatedOn;

	public Issue(int issueId, String summery, String description, User raisedBy, Date createdOn, User assignedBy,
			User assignedTo, Project projectId, String status, String priority, String resolution,
			Date expectedResolutionDate, Date actualResolutionDate, float issueVersion, float fixVersion,
			String fileAttachmentPath, User updatedBy, Date updatedOn) {
		this.issueId = issueId;
		this.summery = summery;
		this.description = description;
		this.raisedBy = raisedBy;
		this.createdOn = createdOn;
		this.assignedBy = assignedBy;
		this.assignedTo = assignedTo;
		this.projectId = projectId;
		this.status = status;
		this.priority = priority;
		this.resolution = resolution;
		this.expectedResolutionDate = expectedResolutionDate;
		this.actualResolutionDate = actualResolutionDate;
		this.issueVersion = issueVersion;
		this.fixVersion = fixVersion;
		this.fileAttachmentPath = fileAttachmentPath;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
	}

	public int getIssueId() {
		return issueId;
	}

	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}

	public String getSummery() {
		return summery;
	}

	public void setSummery(String summery) {
		this.summery = summery;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public User getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(User raisedBy) {
		this.raisedBy = raisedBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public User getAssignedBy() {
		return assignedBy;
	}

	public void setAssignedBy(User assignedBy) {
		this.assignedBy = assignedBy;
	}

	public User getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}

	public Project getProjectId() {
		return projectId;
	}

	public void setProjectId(Project projectId) {
		this.projectId = projectId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public Date getExpectedResolutionDate() {
		return expectedResolutionDate;
	}

	public void setExpectedResolutionDate(Date expectedResolutionDate) {
		this.expectedResolutionDate = expectedResolutionDate;
	}

	public Date getActualResolutionDate() {
		return actualResolutionDate;
	}

	public void setActualResolutionDate(Date actualResolutionDate) {
		this.actualResolutionDate = actualResolutionDate;
	}

	public float getIssueVersion() {
		return issueVersion;
	}

	public void setIssueVersion(float issueVersion) {
		this.issueVersion = issueVersion;
	}

	public float getFixVersion() {
		return fixVersion;
	}

	public void setFixVersion(float fixVersion) {
		this.fixVersion = fixVersion;
	}

	public String getFileAttachmentPath() {
		return fileAttachmentPath;
	}

	public void setFileAttachmentPath(String fileAttachmentPath) {
		this.fileAttachmentPath = fileAttachmentPath;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
